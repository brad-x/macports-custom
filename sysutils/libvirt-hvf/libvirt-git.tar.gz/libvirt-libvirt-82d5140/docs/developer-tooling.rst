=================
Developer tooling
=================

libvirt includes support for some useful development tools right
in its source repository, meaning users will be able to take
advantage of them without little or no configuration. Examples
include:

-  `color_coded <https://github.com/jeaye/color_coded>`__, a vim
   plugin for libclang-powered semantic syntax highlighting;
-  `YouCompleteMe <http://valloric.github.io/YouCompleteMe/>`__, a
   vim plugin for libclang-powered semantic code completion.
